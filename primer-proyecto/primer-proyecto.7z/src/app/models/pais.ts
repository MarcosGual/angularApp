export interface Pais {
  id: string;
  nombre: string;
}
