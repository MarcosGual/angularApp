export interface Ciudad {
    id: string;
    nombre: string;
    paisId: string
  }